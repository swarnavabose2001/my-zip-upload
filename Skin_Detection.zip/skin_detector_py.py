

# skin_detector.py
import cv2
import numpy as np
import os
import pickle
import argparse

# Histogram parameters
NUM_BINS = np.int32(32)
THRESHOLD = 0.5
# Posterior threshold

def rgb_to_bin(r, g, b):
    r = np.clip(r, 0, 255)
    g = np.clip(g, 0, 255)
    b = np.clip(b, 0, 255)
    r_bin = int(r * NUM_BINS / 256)
    g_bin = int(g * NUM_BINS / 256)
    b_bin = int(b * NUM_BINS / 256)
    return r_bin, g_bin, b_bin

def create_histograms(image_paths):
    skin_hist = np.zeros((NUM_BINS, NUM_BINS, NUM_BINS))
    non_skin_hist = np.zeros((NUM_BINS, NUM_BINS, NUM_BINS))
    skin_total, non_skin_total = 0, 0

    for path in image_paths:
        img = cv2.imread(path)
        if img is None:
            raise FileNotFoundError(f"Image not found: {path}")
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        h, w, _ = img_rgb.shape
        mask = ~np.all(img_rgb == [255, 255, 255], axis=-1)  # True for skin pixels
        skin_pixels = img_rgb[mask]
        non_skin_pixels = img_rgb[~mask]

        for pixel in skin_pixels:
            r_bin, g_bin, b_bin = rgb_to_bin(*pixel)
            skin_hist[r_bin, g_bin, b_bin] += 1
            skin_total += 1

        for pixel in non_skin_pixels:
            r_bin, g_bin, b_bin = rgb_to_bin(*pixel)
            non_skin_hist[r_bin, g_bin, b_bin] += 1
            non_skin_total += 1

    # Normalize
    if skin_total > 0:
        skin_hist /= skin_total
    if non_skin_total > 0:
        non_skin_hist /= non_skin_total

    return skin_hist, non_skin_hist

def save_model(skin_hist, non_skin_hist, filename="skin_hist.pkl"):
    with open(filename, "wb") as f:
        pickle.dump((skin_hist, non_skin_hist), f)

def load_model(filename="skin_hist.pkl"):  # changed filename to skin_hist.pkl
    with open(filename, "rb") as f:
        loaded_data = pickle.load(f)
        # Check if the loaded data has the expected structure
        if isinstance(loaded_data, tuple) and len(loaded_data) == 2:
            return loaded_data
        else:
            raise ValueError(f"Unexpected data format in {filename}")

def classify_skin(image, skin_hist, non_skin_hist):
    img_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB).astype(np.int32)  # Change data type to int32
    h, w, _ = img_rgb.shape
    bins = NUM_BINS
    idx = (img_rgb * bins // 256).clip(0, bins - 1)

    r, g, b = idx[..., 0], idx[..., 1], idx[..., 2]
    p_skin = skin_hist[r, g, b]
    p_non = non_skin_hist[r, g, b]
    posterior = p_skin / (p_skin + p_non + 1e-8)

    mask = posterior > THRESHOLD
    output = np.ones_like(img_rgb) * 255
    output[mask] = img_rgb[mask]

    return cv2.cvtColor(output.astype(np.uint8), cv2.COLOR_RGB2BGR) # Convert back to uint8 before returning

def train():
    train_paths = [
        "train_images/train_image1.png",
        "train_images/train_image2.png",
        "train_images/train_image3.png"
    ]
    skin_hist, non_skin_hist = create_histograms(train_paths)
    save_model(skin_hist, non_skin_hist)
    print("[INFO] Skin model trained and saved.")

def test():
    skin_hist, non_skin_hist = load_model()
    test_images = ["test_images/test_image1.png", "test_images/test_image2.png"]
    os.makedirs("output", exist_ok=True)
    for i, path in enumerate(test_images):
        img = cv2.imread(path)
        if img is None:
            print(f"[WARNING] Couldn't read {path}")
            continue
        result = classify_skin(img, skin_hist, non_skin_hist)
        output_path = f"output/result_{i+1}.png"
        cv2.imwrite(output_path, result)
        print(f"[INFO] Processed {path}, saved output to {output_path}")

if __name__ == "__main__":
    import sys
    sys.argv = ['Skin_detector.py', '--mode', 'test']  # Replace 'test' with 'train' if needed

    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["train", "test"], required=True, help="Mode: train or test")
    args = parser.parse_args()

    if args.mode == "train":
        train()
    elif args.mode == "test":
        sys.argv = ['script_name.py', '--mode', 'test'] # change mode to test
        args = parser.parse_args() # parse args again
        test()