Skin Segmentation Using Histogram-Based Color Model
----------------------------------------------------

Author: [Your Name]
Date: [Date]

Requirements:
-------------
- Python 3.x
- OpenCV
- NumPy

Install dependencies:
---------------------
pip install opencv-python numpy

Directory Structure:
--------------------
skin_segmentation/
├── train_images/
│   ├── train1.png  --> skin-only image (non-skin = white)
│   ├── train2.png
│   ├── train3.png
├── test_images/
│   ├── test1.png   --> full original test image
│   ├── test2.png
├── output/
├── skin_detector.py
├── readme.txt
|--- skin_hist.pkl

Running the Code:
-----------------

1. We train the skin model using the labeled skin images.

2. We test the model on test images.

Results:
--------
Segmented images will be saved in the `output/` directory as:
- `result_1.png`
- `result_2.png`

In the output images, skin pixels are preserved, and all others are white.





