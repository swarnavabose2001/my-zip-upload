
#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <vector>
#include <string>
#include <bitset>

using namespace std;

// Register map
unordered_map<string, int> registerMap = {
    {"x0", 0}, {"x1", 1}, {"x2", 2}, {"x3", 3}, {"x4", 4},
    {"x5", 5}, {"x6", 6}, {"x7", 7}, {"x8", 8}, {"x9", 9},
    {"x10", 10}, {"x11", 11}, {"x12", 12}, {"x13", 13},
    {"x14", 14}, {"x15", 15}, {"x16", 16}, {"x17", 17},
    {"x18", 18}, {"x19", 19}, {"x20", 20}, {"x21", 21},
    {"x22", 22}, {"x23", 23}, {"x24", 24}, {"x25", 25},
    {"x26", 26}, {"x27", 27}, {"x28", 28}, {"x29", 29},
    {"x30", 30}, {"x31", 31}
};

// Opcode map
unordered_map<string, string> opcodeMap = {
    {"addi", "0010011"}, {"ori", "0010011"},
    {"add", "0110011"}, {"mul", "0110011"}, {"beq", "1100011"},
    {"bne", "1100011"}, {"blt", "1100011"}, {"bge", "1100011"},
    {"lw", "0000011"}, {"sw", "0100011"}, {"li", "0010011"},
    {"jalr", "1100111"}, {"jal", "1101111"},{"ble","0101010"}
};

// Funct3 map
unordered_map<string, string> funct3Map = {
    {"addi", "000"}, {"andi", "111"}, {"ori", "110"},
    {"add", "000"}, {"mul", "000"}, {"beq", "000"},
    {"bne", "001"}, {"blt", "100"}, {"bge", "101"},
    {"lw", "010"}, {"sw", "010"}, {"jalr", "000"},{"ble","011"}
};

// Funct7 map
unordered_map<string, string> funct7Map = {
    {"add", "0000000"}, {"mul", "0000001"}
};

// Encode R-type instruction
string encodeRType(string opcode, string funct3, string funct7, string rd, string rs1, string rs2) {
    return funct7 + bitset<5>(stoi(rs2)).to_string() + bitset<5>(stoi(rs1)).to_string() +
           funct3 + bitset<5>(stoi(rd)).to_string() + opcode;
}

// Encode I-type instruction
string encodeIType(string opcode, string funct3, string rd, string rs1, int imm) {
    return bitset<12>(imm).to_string() + bitset<5>(stoi(rs1)).to_string() +
           funct3 + bitset<5>(stoi(rd)).to_string() + opcode;
}

// Encode SB-type instruction
string encodeSBType(string opcode, string funct3, string rs1, string rs2, int offset) {
    string imm = bitset<13>(offset).to_string();
    return imm[0] + imm.substr(2, 6) + bitset<5>(stoi(rs2)).to_string() +
           bitset<5>(stoi(rs1)).to_string() + funct3 + imm.substr(8, 4) + imm[1] + opcode;
}
string encodeSType(string opcode, string funct3, string rs2, string rs1, int imm) {
    string immBinary = bitset<12>(imm).to_string();
    return immBinary.substr(0, 7) + bitset<5>(stoi(rs2)).to_string() +
           bitset<5>(stoi(rs1)).to_string() + funct3 + immBinary.substr(7, 5) + opcode;
}

// Main assembler function
void assemble(const string &inputFile, const string &outputFile) {
    ifstream inFile(inputFile);
    ofstream outFile(outputFile);

    if (!inFile.is_open() || !outFile.is_open()) {
        cerr << "Error opening file!" << endl;
        return;
    }

    string line;
    while (getline(inFile, line)) {
        istringstream iss(line);
        string instruction, rd, rs1, rs2;
        int imm;

        iss >> instruction;
        if (instruction == "add" || instruction == "mul") {
            iss >> rd >> rs1 >> rs2;
            rd = rd.substr(1); // Remove 'x' prefix
            rs1 = rs1.substr(1);
            rs2 = rs2.substr(1);
            string binary = encodeRType(opcodeMap[instruction], funct3Map[instruction], funct7Map[instruction], rd, rs1, rs2);
            outFile << binary << endl;
        } else if (instruction == "addi" || instruction == "andi") {
            iss >> rd >> rs1 >> imm;
            rd = rd.substr(1);
            rs1 = rs1.substr(1);
            string binary = encodeIType(opcodeMap[instruction], funct3Map[instruction], rd, rs1, imm);
            outFile << binary << endl;
        } else if (instruction == "beq" || instruction == "bne"||instruction == "ble"||instruction=="blt") {
            iss >> rs1 >> rs2 >> imm;
            rs1 = rs1.substr(1);
            rs2 = rs2.substr(1);
            string binary = encodeSBType(opcodeMap[instruction], funct3Map[instruction], rs1, rs2, imm);
            outFile << binary << endl;
        }
         else if (instruction == "lw") { // Handling load word
            string offset_rs1;
            iss >> rd >> offset_rs1; 

            size_t openBracket = offset_rs1.find('(');
            size_t closeBracket = offset_rs1.find(')');

            if (openBracket == string::npos || closeBracket == string::npos) {
                cerr << "Error: Invalid lw format -> " << line << endl;
                continue;
            }

            imm = stoi(offset_rs1.substr(0, openBracket));  // Extract offset
            rs1 = offset_rs1.substr(openBracket + 2, closeBracket - openBracket - 2); // Extract rs1 (removing 'x')

            string binary = encodeIType(opcodeMap["lw"], funct3Map["lw"], rd.substr(1), rs1, imm);
            outFile << binary << endl;
        }
        else if (instruction == "sw") { // Handling store word
            string offset_rs1;
            iss >> rs2 >> offset_rs1;

            size_t openBracket = offset_rs1.find('(');
            size_t closeBracket = offset_rs1.find(')');

            if (openBracket == string::npos || closeBracket == string::npos) {
                cerr << "Error: Invalid sw format -> " << line << endl;
                continue;
            }

            imm = stoi(offset_rs1.substr(0, openBracket));  // Extract offset
            rs1 = offset_rs1.substr(openBracket + 2, closeBracket - openBracket - 2); // Extract rs1 (removing 'x')

            string binary = encodeSType(opcodeMap["sw"], funct3Map["sw"], rs1, rs2.substr(1), imm);
            outFile << binary << endl;
        }
    }

    inFile.close();
    outFile.close();
}

int main() {
    string inputFile = "assembly.txt";
    string outputFile = "binary.txt";

    assemble(inputFile, outputFile);

    cout << "Assembly successfully converted to binary!" << endl;
    return 0;
}
