First run the "Server.java" file to start the server.
Then run the "Client.java" file.
Run the file "Client.java" in different terminals multiple times to create multiple clients.
The questions Q1, Q2 and Q3 of the Lab assignment 1 are implemented together in that code.
To implement Q4, run the file "ManInTheMiddle.java" in another terminal.
