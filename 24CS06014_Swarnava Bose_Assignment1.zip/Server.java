import java.io.*;
import java.net.*;
import java.math.BigInteger;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.util.*;
import java.util.concurrent.*;

public class Server {
    private static final int PORT = 12345;
    private static final BigInteger P = new BigInteger("23");
    private static final BigInteger G = new BigInteger("5");
    private static final BigInteger PRIVATE_KEY = new BigInteger("6");

    private static final Map<Integer, ClientHandler> clients = new ConcurrentHashMap<>();
    private static int clientIdCounter = 1;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server started, waiting for clients...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getRemoteSocketAddress());
                int clientId = clientIdCounter++;
                ClientHandler clientHandler = new ClientHandler(clientSocket, clientId);
                clients.put(clientId, clientHandler);
                clientHandler.start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler extends Thread {
        private final Socket socket;
        private final int clientId;
        private BufferedReader in;
        private PrintWriter out;
        private SecretKeySpec rc4Key;

        public ClientHandler(Socket socket, int clientId) {
            this.socket = socket;
            this.clientId = clientId;
        }

        @Override
        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

                // Send server's public key
                BigInteger serverPublicKey = G.modPow(PRIVATE_KEY, P);
                out.println(serverPublicKey.toString());

                // Receive client's public key
                BigInteger clientPublicKey = new BigInteger(in.readLine());

                // Compute shared secret
                BigInteger sharedSecret = clientPublicKey.modPow(PRIVATE_KEY, P);
                byte[] keyBytes = sharedSecret.toByteArray();

                // Ensure key length for RC4 is 16 bytes
                byte[] key16Bytes = new byte[16];
                System.arraycopy(keyBytes, 0, key16Bytes, 0, Math.min(keyBytes.length, 16));
                rc4Key = new SecretKeySpec(key16Bytes, "RC4");

                String message;
                while ((message = in.readLine()) != null) {
                    String decryptedMessage = decrypt(message);
                    System.out.println("Received from client " + clientId + ": " + decryptedMessage);
                    // Optionally: Send message to all other clients
                    for (ClientHandler handler : clients.values()) {
                        if (handler != this) {
                            handler.sendMessage("Client " + clientId + ": " + decryptedMessage);
                        }
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                clients.remove(clientId);
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private String decrypt(String encryptedMessage) throws IOException {
            byte[] encryptedBytes = decodeBase64(encryptedMessage);
            Cipher cipher;
            try {
                cipher = Cipher.getInstance("RC4");
                cipher.init(Cipher.DECRYPT_MODE, rc4Key);
                byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
                return new String(decryptedBytes, "UTF-8");
            } catch (GeneralSecurityException e) {
                throw new IOException("Decryption error", e);
            }
        }

        private void sendMessage(String message) {
            try {
                String encryptedMessage = encrypt(message, rc4Key);
                out.println(encryptedMessage);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private String encrypt(String message, SecretKeySpec rc4Key) throws IOException {
            try {
                Cipher cipher = Cipher.getInstance("RC4");
                cipher.init(Cipher.ENCRYPT_MODE, rc4Key);
                byte[] encryptedBytes = cipher.doFinal(message.getBytes("UTF-8"));
                return encodeBase64(encryptedBytes);
            } catch (GeneralSecurityException e) {
                throw new IOException("Encryption error", e);
            }
        }

        private static byte[] decodeBase64(String encoded) {
            final String BASE64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
            int padding = 0;
            int length = encoded.length();
            if (encoded.endsWith("=="))
                padding = 2;
            else if (encoded.endsWith("="))
                padding = 1;

            int outputLength = (length * 3) / 4 - padding;
            byte[] decoded = new byte[outputLength];

            int buffer = 0;
            int bits = 0;
            int index = 0;
            for (char c : encoded.toCharArray()) {
                if (c == '=')
                    break;
                int value = BASE64_CHARS.indexOf(c);
                if (value == -1)
                    throw new IllegalArgumentException("Invalid Base64 character: " + c);
                buffer = (buffer << 6) | value;
                bits += 6;
                if (bits >= 8) {
                    bits -= 8;
                    decoded[index++] = (byte) ((buffer >> bits) & 0xFF);
                }
            }
            return decoded;
        }

        private static String encodeBase64(byte[] data) {
            final String BASE64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
            StringBuilder encoded = new StringBuilder((data.length * 4 + 2) / 3);
            int buffer = 0;
            int bits = 0;
            for (byte b : data) {
                buffer = (buffer << 8) | (b & 0xFF);
                bits += 8;
                while (bits >= 6) {
                    bits -= 6;
                    encoded.append(BASE64_CHARS.charAt((buffer >> bits) & 0x3F));
                }
            }
            if (bits > 0) {
                encoded.append(BASE64_CHARS.charAt((buffer << (6 - bits)) & 0x3F));
            }
            while (encoded.length() % 4 != 0) {
                encoded.append('=');
            }
            return encoded.toString();
        }
    }
}
