import java.io.*;
import java.net.*;
import java.math.BigInteger;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;

public class Client {
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 12345;
    private static final BigInteger P = new BigInteger("23"); // Example prime number
    private static final BigInteger G = new BigInteger("5"); // Example base
    private static final BigInteger PRIVATE_KEY = new BigInteger("15"); // Example private key

    private static int clientId;

    public static void main(String[] args) {
        try (Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in))) {

            // Get client's ID
            System.out.print("Enter client ID: ");
            clientId = Integer.parseInt(userInput.readLine());

            // Receive server's public key
            BigInteger serverPublicKey = new BigInteger(in.readLine());

            // Send client's public key
            BigInteger clientPublicKey = G.modPow(PRIVATE_KEY, P);
            out.println(clientPublicKey.toString());

            // Receive the server's public key
            BigInteger serverPublicKeyReceived = new BigInteger(in.readLine());

            // Compute shared secret
            BigInteger sharedSecret = serverPublicKeyReceived.modPow(PRIVATE_KEY, P);
            byte[] keyBytes = sharedSecret.toByteArray();

            // Ensure key length for RC4 is 16 bytes
            byte[] key16Bytes = new byte[16];
            System.arraycopy(keyBytes, 0, key16Bytes, 0, Math.min(keyBytes.length, 16));
            SecretKeySpec rc4Key = new SecretKeySpec(key16Bytes, "RC4");

            // Start a thread to listen for incoming messages
            new Thread(() -> {
                String message;
                try {
                    while ((message = in.readLine()) != null) {
                        String decryptedMessage = decrypt(message, rc4Key);
                        System.out.println("Received: " + decryptedMessage);
                    }
                } catch (IOException e) {
                    System.err.println("Error receiving message: " + e.getMessage());
                }
            }).start();

            // Send messages
            String input;
            while ((input = userInput.readLine()) != null) {
                String messageWithId = clientId + ": " + input;
                String encryptedMessage = encrypt(messageWithId, rc4Key);
                out.println(encryptedMessage);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String encrypt(String message, SecretKeySpec rc4Key) throws IOException {
        try {
            Cipher cipher = Cipher.getInstance("RC4");
            cipher.init(Cipher.ENCRYPT_MODE, rc4Key);
            byte[] encryptedBytes = cipher.doFinal(message.getBytes("UTF-8"));
            return encodeBase64(encryptedBytes);
        } catch (GeneralSecurityException e) {
            throw new IOException("Encryption error", e);
        }
    }

    private static String decrypt(String encryptedMessage, SecretKeySpec rc4Key) throws IOException {
        try {
            byte[] encryptedBytes = decodeBase64(encryptedMessage);
            Cipher cipher = Cipher.getInstance("RC4");
            cipher.init(Cipher.DECRYPT_MODE, rc4Key);
            byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
            return new String(decryptedBytes, "UTF-8");
        } catch (GeneralSecurityException e) {
            throw new IOException("Decryption error", e);
        }
    }

    private static byte[] decodeBase64(String encoded) {
        final String BASE64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        int padding = 0;
        int length = encoded.length();
        if (encoded.endsWith("=="))
            padding = 2;
        else if (encoded.endsWith("="))
            padding = 1;

        int outputLength = (length * 3) / 4 - padding;
        byte[] decoded = new byte[outputLength];

        int buffer = 0;
        int bits = 0;
        int index = 0;
        for (char c : encoded.toCharArray()) {
            if (c == '=')
                break;
            int value = BASE64_CHARS.indexOf(c);
            if (value == -1)
                throw new IllegalArgumentException("Invalid Base64 character: " + c);
            buffer = (buffer << 6) | value;
            bits += 6;
            if (bits >= 8) {
                bits -= 8;
                decoded[index++] = (byte) ((buffer >> bits) & 0xFF);
            }
        }
        return decoded;
    }

    private static String encodeBase64(byte[] data) {
        final String BASE64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        StringBuilder encoded = new StringBuilder((data.length * 4 + 2) / 3);
        int buffer = 0;
        int bits = 0;
        for (byte b : data) {
            buffer = (buffer << 8) | (b & 0xFF);
            bits += 8;
            while (bits >= 6) {
                bits -= 6;
                encoded.append(BASE64_CHARS.charAt((buffer >> bits) & 0x3F));
            }
        }
        if (bits > 0) {
            encoded.append(BASE64_CHARS.charAt((buffer << (6 - bits)) & 0x3F));
        }
        while (encoded.length() % 4 != 0) {
            encoded.append('=');
        }
        return encoded.toString();
    }
}
