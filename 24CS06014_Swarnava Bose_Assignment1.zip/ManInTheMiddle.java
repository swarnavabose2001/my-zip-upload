import java.io.*;
import java.net.*;
import java.math.BigInteger;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.util.*;
import java.util.concurrent.*;

public class ManInTheMiddle {
    private static final int PORT = 12345;
    private static final BigInteger P = new BigInteger("23");
    private static final BigInteger G = new BigInteger("5");
    private static final List<BigInteger> PRIVATE_KEYS = Arrays.asList(
            new BigInteger("1"), new BigInteger("2"), new BigInteger("3"), new BigInteger("4"), new BigInteger("5")
    // Add more possible private keys here
    );

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("MitM server started, waiting for connections...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getRemoteSocketAddress());
                new Thread(new ProxyHandler(clientSocket)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ProxyHandler implements Runnable {
        private final Socket clientSocket;
        private Socket serverSocket;
        private BufferedReader clientIn;
        private PrintWriter clientOut;
        private BufferedReader serverIn;
        private PrintWriter serverOut;
        private SecretKeySpec rc4Key;
        private BigInteger clientPublicKey;
        private BigInteger serverPublicKey;
        private BigInteger sharedSecret;

        public ProxyHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try {
                setupConnections();

                // Intercept client public key
                clientPublicKey = new BigInteger(clientIn.readLine());

                // Forward server's public key to client
                serverOut.println(serverPublicKey.toString());

                // Receive and store server's public key
                serverPublicKey = new BigInteger(serverIn.readLine());

                // Compute and brute-force the shared secret
                bruteForcePrivateKey();

                // Intercept and forward messages
                forwardMessages();

            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    clientSocket.close();
                    if (serverSocket != null)
                        serverSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private void setupConnections() throws IOException {
            // Connect to the actual server
            serverSocket = new Socket("localhost", PORT);
            serverIn = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));
            serverOut = new PrintWriter(serverSocket.getOutputStream(), true);

            // Set up the connections with the client
            clientIn = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            clientOut = new PrintWriter(clientSocket.getOutputStream(), true);

            // Send the MitM's public key to the client
            BigInteger mitmPrivateKey = new BigInteger("7"); // Example MitM private key
            BigInteger mitmPublicKey = G.modPow(mitmPrivateKey, P);
            serverOut.println(mitmPublicKey.toString()); // Forward MitM public key to the server
            clientOut.println(mitmPublicKey.toString()); // Forward MitM public key to the client
        }

        private void bruteForcePrivateKey() {
            for (BigInteger privateKey : PRIVATE_KEYS) {
                BigInteger testSharedSecret = serverPublicKey.modPow(privateKey, P);
                byte[] keyBytes = testSharedSecret.toByteArray();
                byte[] key16Bytes = new byte[16];
                System.arraycopy(keyBytes, 0, key16Bytes, 0, Math.min(keyBytes.length, 16));
                rc4Key = new SecretKeySpec(key16Bytes, "RC4");

                if (testDecryption("Encrypted message to test", rc4Key)) {
                    sharedSecret = testSharedSecret;
                    break;
                }
            }
        }

        private boolean testDecryption(String encryptedMessage, SecretKeySpec rc4Key) {
            try {
                Cipher cipher = Cipher.getInstance("RC4");
                cipher.init(Cipher.DECRYPT_MODE, rc4Key);
                cipher.doFinal(decodeBase64(encryptedMessage));
                return true;
            } catch (GeneralSecurityException e) {
                return false;
            }
        }

        private void forwardMessages() throws IOException {
            // Forward messages between client and server
            String message;
            while ((message = clientIn.readLine()) != null) {
                serverOut.println(message); // Forward to server
            }
            while ((message = serverIn.readLine()) != null) {
                clientOut.println(message); // Forward to client
            }
        }

        private static byte[] decodeBase64(String encoded) {
            final String BASE64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
            int padding = 0;
            int length = encoded.length();
            if (encoded.endsWith("=="))
                padding = 2;
            else if (encoded.endsWith("="))
                padding = 1;

            int outputLength = (length * 3) / 4 - padding;
            byte[] decoded = new byte[outputLength];

            int buffer = 0;
            int bits = 0;
            int index = 0;
            for (char c : encoded.toCharArray()) {
                if (c == '=')
                    break;
                int value = BASE64_CHARS.indexOf(c);
                if (value == -1)
                    throw new IllegalArgumentException("Invalid Base64 character: " + c);
                buffer = (buffer << 6) | value;
                bits += 6;
                if (bits >= 8) {
                    bits -= 8;
                    decoded[index++] = (byte) ((buffer >> bits) & 0xFF);
                }
            }
            return decoded;
        }
    }
}
