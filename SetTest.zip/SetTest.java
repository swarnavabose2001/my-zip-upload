import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

 public class SetTest {

    @Test
    public void testInsertAndToArray() {
        Set s = new Set();
        s.insert(5);
        s.insert(3);
        s.insert(5); // duplicate
        s.insert(7);
        s.insert(1);
        assertArrayEquals(new int[]{1, 3, 5, 7}, s.toArray());
    }

    @Test
    public void testMember() {
        Set s = new Set();
        s.insert(10);
        s.insert(20);
        s.insert(30);
        assertTrue(s.member(10));
        assertTrue(s.member(20));
        assertFalse(s.member(15));
        assertFalse(s.member(100));
    }

    @Test
    public void testSection() {
        Set a = new Set();
        a.insert(1);
        a.insert(2);
        a.insert(3);
        a.insert(4);

        Set b = new Set();
        b.insert(2);
        b.insert(4);
        b.insert(6);

        a.section(b);
        assertArrayEquals(new int[]{1, 3}, a.toArray());
    }

    @Test
    public void testContainsArithTripleTrue() {
        Set s = new Set();
        s.insert(1);
        s.insert(3);
        s.insert(5); // 1, 3, 5 => 3 - 1 = 2, 5 - 3 = 2
        assertTrue(s.containsArithTriple());
    }

    @Test
    public void testContainsArithTripleFalse() {
        Set s = new Set();
        s.insert(2);
        s.insert(5);
        s.insert(8); // no arithmetic triple
        assertFalse(s.containsArithTriple());
    }

    @Test
    public void testEmptySet() {
        Set s = new Set();
        assertFalse(s.member(5));
        assertFalse(s.containsArithTriple());
        assertArrayEquals(new int[]{}, s.toArray());
    }

    @Test
    public void testInsertSortedAndNoDuplicates() {
        Set s = new Set();
        s.insert(10);
        s.insert(5);
        s.insert(5);
        s.insert(7);
        s.insert(12);
        assertArrayEquals(new int[]{5, 7, 10, 12}, s.toArray());
    }
}

